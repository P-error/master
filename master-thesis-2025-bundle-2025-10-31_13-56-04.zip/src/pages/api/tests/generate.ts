// src/pages/api/tests/generate.ts
export { default } from "../generate-test";
