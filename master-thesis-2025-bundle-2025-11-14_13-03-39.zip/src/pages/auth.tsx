export default function Auth() {
    return <h1 className="text-2xl font-bold">Login / Register Page</h1>;
  }
  