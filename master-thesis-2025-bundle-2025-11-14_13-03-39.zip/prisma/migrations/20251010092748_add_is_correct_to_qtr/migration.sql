-- AlterTable
ALTER TABLE "QuestionTagResult" ADD COLUMN     "isCorrect" BOOLEAN;
