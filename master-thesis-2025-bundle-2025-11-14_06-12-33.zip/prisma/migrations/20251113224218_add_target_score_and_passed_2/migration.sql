-- AlterTable
ALTER TABLE "TestAttempt" ADD COLUMN     "passed" BOOLEAN,
ADD COLUMN     "targetScore" INTEGER;
