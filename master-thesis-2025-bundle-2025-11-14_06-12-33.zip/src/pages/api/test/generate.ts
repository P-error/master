// src/pages/api/test/generate.ts
export { default } from "../generate-test";
