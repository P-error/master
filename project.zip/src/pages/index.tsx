export default function Home() {
  return (
    <div className="p-6 bg-blue-500 text-white rounded-xl shadow">
      Tailwind OK (prod test)
    </div>
  );
}
